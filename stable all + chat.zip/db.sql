/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 80030 (8.0.30)
 Source Host           : localhost:3306
 Source Schema         : sticker

 Target Server Type    : MySQL
 Target Server Version : 80030 (8.0.30)
 File Encoding         : 65001

 Date: 22/12/2024 13:41:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for chat_messages
-- ----------------------------
DROP TABLE IF EXISTS `chat_messages`;
CREATE TABLE `chat_messages`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `trade_id` int NOT NULL,
  `user_id` int NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_delivered` tinyint(1) NULL DEFAULT 1,
  `is_read` tinyint(1) NULL DEFAULT 0,
  `read_at` datetime NULL DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `idx_trade_user`(`trade_id` ASC, `user_id` ASC) USING BTREE,
  INDEX `idx_status`(`is_read` ASC, `read_at` ASC) USING BTREE,
  INDEX `idx_chat_created`(`created_at` ASC) USING BTREE,
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`trade_id`) REFERENCES `trades` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chat_messages
-- ----------------------------

-- ----------------------------
-- Table structure for notifications
-- ----------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NULL DEFAULT 0,
  `reference_id` int NULL DEFAULT NULL,
  `reference_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_notifications_user`(`user_id` ASC) USING BTREE,
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notifications
-- ----------------------------
INSERT INTO `notifications` VALUES (1, 1, 'trade_request', 'Permintaan Pertukaran Baru', 'Ada yang ingin menukar stiker dengan Anda', 0, 3, 'trade', '2024-12-22 13:39:44', NULL);

-- ----------------------------
-- Table structure for sticker_categories
-- ----------------------------
DROP TABLE IF EXISTS `sticker_categories`;
CREATE TABLE `sticker_categories`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sticker_categories
-- ----------------------------
INSERT INTO `sticker_categories` VALUES (1, 'Indonesia Map', 'indonesia-map', '1', '2024-12-22 01:27:43', NULL);
INSERT INTO `sticker_categories` VALUES (2, 'World Map', 'world-map', '2', '2024-12-22 01:27:58', NULL);
INSERT INTO `sticker_categories` VALUES (3, 'Space Station Map', 'space-station-map', '3', '2024-12-22 01:28:37', NULL);
INSERT INTO `sticker_categories` VALUES (4, 'Theme Park Map', 'theme-park-map', '4', '2024-12-22 01:28:46', NULL);
INSERT INTO `sticker_categories` VALUES (5, 'Adventure Map', 'adventure-map', '5', '2024-12-22 01:28:56', NULL);
INSERT INTO `sticker_categories` VALUES (6, 'Fortress', 'fortress', '6', '2024-12-22 01:29:05', NULL);
INSERT INTO `sticker_categories` VALUES (7, 'Zombie Map', 'zombie-map', '7', '2024-12-22 01:29:14', NULL);
INSERT INTO `sticker_categories` VALUES (8, 'God\'s Hand', 'gods-hand', '8', '2024-12-22 01:29:24', NULL);
INSERT INTO `sticker_categories` VALUES (9, 'Magic Land', 'magic-land', '9', '2024-12-22 01:29:34', NULL);
INSERT INTO `sticker_categories` VALUES (10, 'Ice Cave', 'ice-cave', '10', '2024-12-22 01:29:44', NULL);
INSERT INTO `sticker_categories` VALUES (11, 'Toy Land', 'toy-land', '11', '2024-12-22 01:29:55', NULL);
INSERT INTO `sticker_categories` VALUES (12, 'Water City', 'water-city', '12', '2024-12-22 01:30:03', NULL);

-- ----------------------------
-- Table structure for stickers
-- ----------------------------
DROP TABLE IF EXISTS `stickers`;
CREATE TABLE `stickers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` int NULL DEFAULT NULL,
  `category_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NULL DEFAULT NULL,
  `quantity` int NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_stickers_category`(`category_id` ASC) USING BTREE,
  CONSTRAINT `stickers_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `sticker_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 109 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of stickers
-- ----------------------------
INSERT INTO `stickers` VALUES (1, NULL, 1, '2024-12-22 01:27:43', '2024-12-22 01:31:27', 0);
INSERT INTO `stickers` VALUES (2, NULL, 1, '2024-12-22 01:27:43', '2024-12-22 02:22:09', 0);
INSERT INTO `stickers` VALUES (3, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (4, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (5, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (6, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (7, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (8, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (9, NULL, 1, '2024-12-22 01:27:43', NULL, 0);
INSERT INTO `stickers` VALUES (10, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (11, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (12, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (13, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (14, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (15, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (16, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (17, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (18, NULL, 2, '2024-12-22 01:27:58', NULL, 0);
INSERT INTO `stickers` VALUES (19, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (20, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (21, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (22, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (23, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (24, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (25, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (26, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (27, NULL, 3, '2024-12-22 01:28:37', NULL, 0);
INSERT INTO `stickers` VALUES (28, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (29, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (30, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (31, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (32, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (33, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (34, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (35, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (36, NULL, 4, '2024-12-22 01:28:46', NULL, 0);
INSERT INTO `stickers` VALUES (37, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (38, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (39, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (40, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (41, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (42, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (43, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (44, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (45, NULL, 5, '2024-12-22 01:28:56', NULL, 0);
INSERT INTO `stickers` VALUES (46, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (47, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (48, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (49, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (50, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (51, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (52, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (53, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (54, NULL, 6, '2024-12-22 01:29:05', NULL, 0);
INSERT INTO `stickers` VALUES (55, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (56, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (57, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (58, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (59, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (60, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (61, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (62, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (63, NULL, 7, '2024-12-22 01:29:14', NULL, 0);
INSERT INTO `stickers` VALUES (64, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (65, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (66, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (67, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (68, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (69, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (70, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (71, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (72, NULL, 8, '2024-12-22 01:29:24', NULL, 0);
INSERT INTO `stickers` VALUES (73, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (74, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (75, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (76, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (77, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (78, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (79, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (80, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (81, NULL, 9, '2024-12-22 01:29:34', NULL, 0);
INSERT INTO `stickers` VALUES (82, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (83, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (84, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (85, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (86, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (87, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (88, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (89, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (90, NULL, 10, '2024-12-22 01:29:44', NULL, 0);
INSERT INTO `stickers` VALUES (91, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (92, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (93, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (94, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (95, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (96, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (97, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (98, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (99, NULL, 11, '2024-12-22 01:29:55', NULL, 0);
INSERT INTO `stickers` VALUES (100, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (101, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (102, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (103, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (104, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (105, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (106, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (107, NULL, 12, '2024-12-22 01:30:03', NULL, 0);
INSERT INTO `stickers` VALUES (108, NULL, 12, '2024-12-22 01:30:03', NULL, 0);

-- ----------------------------
-- Table structure for trades
-- ----------------------------
DROP TABLE IF EXISTS `trades`;
CREATE TABLE `trades`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `requester_id` int NOT NULL,
  `owner_id` int NOT NULL,
  `requested_sticker_id` int NOT NULL,
  `offered_sticker_id` int NOT NULL,
  `status` enum('pending','accepted','rejected','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `requested_sticker_id`(`requested_sticker_id` ASC) USING BTREE,
  INDEX `offered_sticker_id`(`offered_sticker_id` ASC) USING BTREE,
  INDEX `idx_trades_requester`(`requester_id` ASC) USING BTREE,
  INDEX `idx_trades_owner`(`owner_id` ASC) USING BTREE,
  CONSTRAINT `trades_ibfk_1` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `trades_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `trades_ibfk_3` FOREIGN KEY (`requested_sticker_id`) REFERENCES `stickers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `trades_ibfk_4` FOREIGN KEY (`offered_sticker_id`) REFERENCES `stickers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of trades
-- ----------------------------
INSERT INTO `trades` VALUES (3, 3, 1, 10, 1, 'pending', '2024-12-22 13:39:44', NULL);

-- ----------------------------
-- Table structure for user_stickers
-- ----------------------------
DROP TABLE IF EXISTS `user_stickers`;
CREATE TABLE `user_stickers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `sticker_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT 0,
  `is_for_trade` tinyint(1) NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NULL DEFAULT NULL,
  `number` int NOT NULL DEFAULT 1,
  `image_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `image_hash` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_user_sticker_number`(`user_id` ASC, `sticker_id` ASC, `number` ASC) USING BTREE,
  INDEX `idx_user_stickers_user`(`user_id` ASC) USING BTREE,
  INDEX `idx_user_stickers_sticker`(`sticker_id` ASC) USING BTREE,
  CONSTRAINT `user_stickers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_stickers_ibfk_2` FOREIGN KEY (`sticker_id`) REFERENCES `stickers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_stickers
-- ----------------------------
INSERT INTO `user_stickers` VALUES (17, 3, 1, 5, 1, '2024-12-22 13:24:48', '2024-12-22 13:34:13', 1, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70603.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (18, 1, 1, 5, 1, '2024-12-22 13:25:01', '2024-12-22 13:37:19', 5, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (19, 3, 1, 3, 0, '2024-12-22 13:34:13', '2024-12-22 13:34:13', 5, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70603.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (20, 1, 1, 2, 0, '2024-12-22 13:34:40', '2024-12-22 13:37:18', 1, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (21, 1, 1, 1, 0, '2024-12-22 13:34:40', '2024-12-22 13:37:18', 3, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (22, 1, 1, 5, 0, '2024-12-22 13:34:40', '2024-12-22 13:37:19', 9, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (23, 1, 1, 3, 0, '2024-12-22 13:37:19', '2024-12-22 13:37:19', 4, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (24, 1, 1, 1, 0, '2024-12-22 13:37:19', '2024-12-22 13:37:19', 6, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (25, 1, 1, 3, 0, '2024-12-22 13:37:19', '2024-12-22 13:37:19', 7, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (26, 1, 1, 3, 0, '2024-12-22 13:37:19', '2024-12-22 13:37:19', 8, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70605.jpg', '70eb5b59211b76924cff3c6875d93848');
INSERT INTO `user_stickers` VALUES (27, 1, 10, 4, 0, '2024-12-22 13:37:30', '2024-12-22 13:37:30', 1, 'Gambar_WhatsApp_2024-12-22_pukul_08_10_05_cbea70606.jpg', '70eb5b59211b76924cff3c6875d93848');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NULL DEFAULT 1,
  `is_admin` tinyint(1) NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `email`(`email` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Bekoy', 'bzndenis@gmail.com', '$2y$10$Q1oV.uvO5FCUWbQz53t93.rLHRiI467aTOVanipdCK.l5fZhnSoLO', 1, 1, '2024-12-22 01:22:48', NULL);
INSERT INTO `users` VALUES (2, 'Bekoy66', 'bzndenis1@gmail.com', '$2y$10$LIEGPbomOv//F77cJeVKuuHmRNTsHJBpVSV2eXm0YLPHhAuGmOlv.', 1, 0, '2024-12-22 01:31:40', NULL);
INSERT INTO `users` VALUES (3, 'Bekoy666', 'bzndenis11@gmail.com', '$2y$10$UhAEJjy71w3o6S1x21/XHedqUKecd2tQGoZoTbhSmzVC5TI02idbm', 1, 0, '2024-12-22 01:31:59', NULL);

SET FOREIGN_KEY_CHECKS = 1;
