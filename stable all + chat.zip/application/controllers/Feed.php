<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feed extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->check_login();
        $this->load->model(['sticker_model', 'user_model']);
    }
    
    public function index() {
        $user_id = $this->session->userdata('user_id');
        
        // Get feed items
        $data['feed_items'] = $this->sticker_model->get_feed_items($user_id);
        
        // Check if feed items exist and have sticker_id property
        if (!empty($data['feed_items'])) {
            foreach ($data['feed_items'] as &$item) {
                if (!isset($item->sticker_id)) {
                    log_message('error', 'Feed item missing sticker_id property');
                    $item->sticker_id = null;
                }
                // Tambahkan pengecekan apakah stiker bisa ditukar
                $item->can_trade = $this->sticker_model->can_request_trade($user_id, $item->sticker_id);
            }
        }
        
        // Get all categories for search
        $data['categories'] = $this->sticker_model->get_categories();
        
        // Set page title
        $data['title'] = 'Feed Stiker';
        
        $this->load->view('feed/index', $data);
    }
    
    // Add search method
    public function search() {
        $user_id = $this->session->userdata('user_id');
        $category_id = $this->input->get('category');
        
        $data['feed_items'] = $this->sticker_model->get_feed_items($user_id, 20, $category_id);
        $data['categories'] = $this->sticker_model->get_categories();
        $data['selected_category'] = $category_id;
        
        $this->load->view('feed/index', $data);
    }
} 