<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trades extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->check_login();
        $this->load->model(['trade_model', 'sticker_model', 'chat_model', 'notification_model', 'user_model']);
    }
    
    public function index() {
        $user_id = $this->session->userdata('user_id');
        
        // Get daftar pertukaran
        $data['pending_trades'] = $this->trade_model->get_user_trades($user_id, 'pending');
        $data['completed_trades'] = $this->trade_model->get_user_trades($user_id, 'accepted');
        
        $this->load->view('trades/index', $data);
    }
    
    public function request($sticker_id = null) {
        if(!$sticker_id) {
            show_404();
            return;
        }

        $user_id = $this->session->userdata('user_id');
        
        // Get requested sticker with owner info
        $requested_sticker = $this->sticker_model->get_sticker_with_owner($sticker_id);
        if(!$requested_sticker || $requested_sticker->owner_id == $user_id) {
            show_404();
            return;
        }
        
        // Get user's tradeable stickers
        $tradeable_stickers = $this->user_model->get_user_tradeable_stickers($user_id);
        
        $data = [
            'requested_sticker' => $requested_sticker,
            'tradeable_stickers' => $tradeable_stickers
        ];
        
        $this->load->view('trades/request', $data);
    }
    
    public function submit_request() {
        $user_id = $this->session->userdata('user_id');
        $requested_sticker_id = $this->input->post('requested_sticker_id');
        $offered_sticker_id = $this->input->post('offered_sticker_id');
        $owner_id = $this->input->post('owner_id');
        
        // Validasi data
        if(!$requested_sticker_id || !$offered_sticker_id || !$owner_id) {
            $this->session->set_flashdata('error', 'Data tidak lengkap');
            redirect('trades');
            return;
        }
        
        // Buat pertukaran baru
        $trade_data = [
            'requester_id' => $user_id,
            'owner_id' => $owner_id,
            'requested_sticker_id' => $requested_sticker_id,
            'offered_sticker_id' => $offered_sticker_id,
            'status' => 'pending'
        ];
        
        if($this->trade_model->create_trade($trade_data)) {
            // Kirim notifikasi ke pemilik stiker
            $notification_data = [
                'user_id' => $owner_id,
                'type' => 'trade_request',
                'title' => 'Permintaan Pertukaran Baru',
                'message' => 'Ada yang ingin menukar stiker dengan Anda',
                'reference_id' => $this->db->insert_id(),
                'reference_type' => 'trade'
            ];
            $this->notification_model->create_notification($notification_data);
            
            $this->session->set_flashdata('success', 'Permintaan pertukaran berhasil dikirim');
        } else {
            $this->session->set_flashdata('error', 'Gagal mengirim permintaan pertukaran');
        }
        
        redirect('trades');
    }
    
    public function view($trade_id) {
        $user_id = $this->session->userdata('user_id');
        
        // Get data pertukaran
        $data['trade'] = $this->trade_model->get_trade($trade_id);
        if(!$data['trade'] || ($data['trade']->requester_id != $user_id && $data['trade']->owner_id != $user_id)) {
            show_404();
            return;
        }
        
        // Get pesan chat
        $data['messages'] = $this->chat_model->get_trade_messages($trade_id);
        
        $this->load->view('trades/view', $data);
    }
    
    public function send_message() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $user_id = $this->session->userdata('user_id');
        $trade_id = $this->input->post('trade_id');
        $message = trim($this->input->post('message'));
        
        // Validasi trade_id dan kepemilikan
        $trade = $this->trade_model->get_trade($trade_id);
        if(!$trade || ($trade->requester_id != $user_id && $trade->owner_id != $user_id)) {
            echo json_encode(['success' => false, 'message' => 'Pertukaran tidak ditemukan']);
            return;
        }
        
        // Validasi pesan
        if(empty($message)) {
            echo json_encode(['success' => false, 'message' => 'Pesan tidak boleh kosong']);
            return;
        }
        
        // Validasi status trade
        if($trade->status !== 'pending') {
            echo json_encode(['success' => false, 'message' => 'Pertukaran sudah selesai']);
            return;
        }
        
        $message_data = [
            'trade_id' => $trade_id,
            'user_id' => $user_id,
            'message' => $message
        ];
        
        $new_message = $this->chat_model->add_message($message_data);
        if($new_message) {
            // Kirim notifikasi ke penerima chat
            $recipient_id = ($trade->requester_id == $user_id) ? $trade->owner_id : $trade->requester_id;
            $notification_data = [
                'user_id' => $recipient_id,
                'type' => 'new_message',
                'title' => 'Pesan Baru',
                'message' => 'Anda menerima pesan baru di pertukaran',
                'reference_id' => $trade_id,
                'reference_type' => 'trade'
            ];
            $this->notification_model->create_notification($notification_data);
            
            echo json_encode([
                'success' => true,
                'message' => [
                    'id' => $new_message->id,
                    'message' => $new_message->message,
                    'username' => $new_message->username,
                    'created_at' => date('H:i', strtotime($new_message->created_at)),
                    'is_mine' => true
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal mengirim pesan']);
        }
    }
    
    public function accept($trade_id) {
        $user_id = $this->session->userdata('user_id');
        
        // Get data pertukaran
        $trade = $this->trade_model->get_trade($trade_id);
        if(!$trade || $trade->owner_id != $user_id || $trade->status !== 'pending') {
            show_404();
            return;
        }
        
        $this->db->trans_start();
        
        // Update status pertukaran
        $this->trade_model->update_trade_status($trade_id, 'accepted');
        
        // Update kepemilikan stiker
        $this->user_model->update_sticker_quantity($trade->requester_id, $trade->requested_sticker_id, 1);
        $this->user_model->update_sticker_quantity($trade->owner_id, $trade->offered_sticker_id, 1);
        
        // Kurangi jumlah stiker yang ditukar
        $this->user_model->decrease_sticker_quantity($trade->owner_id, $trade->requested_sticker_id);
        $this->user_model->decrease_sticker_quantity($trade->requester_id, $trade->offered_sticker_id);
        
        $this->db->trans_complete();
        
        if($this->db->trans_status()) {
            // Kirim notifikasi ke pemohon
            $notification_data = [
                'user_id' => $trade->requester_id,
                'type' => 'trade_accepted',
                'title' => 'Pertukaran Diterima',
                'message' => 'Permintaan pertukaran Anda telah diterima',
                'reference_id' => $trade_id,
                'reference_type' => 'trade'
            ];
            $this->notification_model->create_notification($notification_data);
            
            $this->session->set_flashdata('success', 'Pertukaran berhasil diterima');
        } else {
            $this->session->set_flashdata('error', 'Gagal memproses pertukaran');
        }
        
        redirect('trades/view/'.$trade_id);
    }
    
    public function reject($trade_id) {
        $user_id = $this->session->userdata('user_id');
        
        // Get data pertukaran
        $trade = $this->trade_model->get_trade($trade_id);
        if(!$trade || $trade->owner_id != $user_id || $trade->status !== 'pending') {
            show_404();
            return;
        }
        
        if($this->trade_model->update_trade_status($trade_id, 'rejected')) {
            // Kirim notifikasi ke pemohon
            $notification_data = [
                'user_id' => $trade->requester_id,
                'type' => 'trade_rejected',
                'title' => 'Pertukaran Ditolak',
                'message' => 'Permintaan pertukaran Anda telah ditolak',
                'reference_id' => $trade_id,
                'reference_type' => 'trade'
            ];
            $this->notification_model->create_notification($notification_data);
            
            $this->session->set_flashdata('success', 'Pertukaran berhasil ditolak');
        } else {
            $this->session->set_flashdata('error', 'Gagal menolak pertukaran');
        }
        
        redirect('trades/view/'.$trade_id);
    }
    
    public function get_new_messages() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $user_id = $this->session->userdata('user_id');
        $trade_id = $this->input->get('trade_id');
        $last_id = $this->input->get('last_id');
        
        // Validasi input
        if(!$trade_id || !isset($last_id)) {
            echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
            return;
        }
        
        // Validasi kepemilikan trade
        $trade = $this->trade_model->get_trade($trade_id);
        if(!$trade || ($trade->requester_id != $user_id && $trade->owner_id != $user_id)) {
            echo json_encode(['success' => false, 'message' => 'Akses ditolak']);
            return;
        }
        
        // Get pesan baru dari orang lain saja
        $messages = $this->chat_model->get_new_messages($trade_id, $last_id, $user_id);
        
        // Format pesan untuk response
        $formatted_messages = array_map(function($msg) use ($user_id) {
            return [
                'id' => $msg->id,
                'message' => $msg->message,
                'username' => $msg->username,
                'created_at' => date('H:i', strtotime($msg->created_at)),
                'is_mine' => false // Selalu false karena ini pesan dari orang lain
            ];
        }, $messages);
        
        // Mark messages as read
        if(!empty($messages)) {
            $this->chat_model->mark_messages_as_read($trade_id, $user_id);
        }
        
        echo json_encode([
            'success' => true,
            'status' => 'success',
            'messages' => $formatted_messages
        ]);
    }
    
    public function get_message_status() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $user_id = $this->session->userdata('user_id');
        $trade_id = $this->input->get('trade_id');
        
        // Get status pesan yang dikirim oleh user
        $messages = $this->chat_model->get_message_status($trade_id, $user_id);
        
        echo json_encode([
            'success' => true,
            'messages' => $messages
        ]);
    }
    
    public function mark_messages_read() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $user_id = $this->session->userdata('user_id');
        $trade_id = $this->input->post('trade_id');
        
        // Validasi kepemilikan trade
        $trade = $this->trade_model->get_trade($trade_id);
        if(!$trade || ($trade->requester_id != $user_id && $trade->owner_id != $user_id)) {
            echo json_encode(['success' => false, 'message' => 'Akses ditolak']);
            return;
        }
        
        // Tandai pesan sebagai dibaca
        $this->chat_model->mark_messages_as_read($trade_id, $user_id);
        
        echo json_encode(['success' => true]);
    }
} 