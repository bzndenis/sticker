<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notifications extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->check_login();
        $this->load->model('notification_model');
        $this->load->library('pagination');
    }
    
    public function index() {
        $user_id = $this->session->userdata('user_id');
        
        // Konfigurasi pagination
        $config['base_url'] = base_url('notifications/index');
        $config['total_rows'] = $this->notification_model->count_user_notifications($user_id);
        $config['per_page'] = 20;
        $config['uri_segment'] = 3;
        
        // Bootstrap 5 pagination style
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a href="#" class="page-link">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['attributes'] = array('class' => 'page-link');
        
        $this->pagination->initialize($config);
        
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data['notifications'] = $this->notification_model->get_user_notifications($user_id, $config['per_page'], $page);
        
        $this->load->view('notifications/index', $data);
    }
    
    public function mark_read($id) {
        $user_id = $this->session->userdata('user_id');
        $result = $this->notification_model->mark_as_read($id, $user_id);
        $this->output->set_content_type('application/json');
        echo json_encode(['success' => $result]);
    }
    
    public function mark_all_read() {
        $user_id = $this->session->userdata('user_id');
        $result = $this->notification_model->mark_all_as_read($user_id);
        $this->output->set_content_type('application/json');
        echo json_encode(['success' => $result]);
    }
    
    public function delete_all() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }

        $user_id = $this->session->userdata('user_id');
        
        $this->db->trans_start();
        
        // Hapus semua notifikasi user
        $result = $this->notification_model->delete_all($user_id);
        
        $this->db->trans_complete();
        
        $success = ($this->db->trans_status() && $result);
        
        $this->output->set_content_type('application/json');
        echo json_encode([
            'success' => $success,
            'message' => $success ? 'Berhasil menghapus semua notifikasi' : 'Gagal menghapus notifikasi'
        ]);
    }

    public function delete($id) {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }

        $user_id = $this->session->userdata('user_id');
        
        $this->db->trans_start();
        
        // Hapus notifikasi spesifik
        $result = $this->notification_model->delete_notification($id, $user_id);
        
        $this->db->trans_complete();
        
        $success = ($this->db->trans_status() && $result);
        
        $this->output->set_content_type('application/json');
        echo json_encode([
            'success' => $success,
            'message' => $success ? 'Berhasil menghapus notifikasi' : 'Gagal menghapus notifikasi'
        ]);
    }
} 