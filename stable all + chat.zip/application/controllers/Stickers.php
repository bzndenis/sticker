<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stickers extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->check_login();
        $this->load->library(['upload', 'image_lib']);
    }
    
    public function view($id) {
        $user_id = $this->session->userdata('user_id');
        
        // Get sticker data with stats
        $data['sticker'] = $this->sticker_model->get_sticker_stats($id);
        if(!$data['sticker']) {
            show_404();
            return;
        }
        
        // Get collection info
        $data['collection'] = $this->sticker_model->get_collection($data['sticker']->collection_id);
        
        // Get user ownership
        $data['ownership'] = $this->user_model->get_user_sticker($user_id, $id);
        
        // Get trade history
        $data['trades'] = $this->trade_model->get_sticker_trades($id);
        
        $this->load->view('stickers/view', $data);
    }
    
    public function toggle_trade($id = null) {
        $user_id = $this->session->userdata('user_id');
        
        // Handle AJAX request
        if($this->input->is_ajax_request()) {
            $sticker_id = $this->input->post('sticker_id');
            $result = $this->user_model->toggle_sticker_trade($user_id, $sticker_id);
            echo json_encode(['success' => $result]);
            return;
        }
        
        // Handle normal request
        if($id) {
            $sticker = $this->user_model->get_user_sticker($user_id, $id);
            if(!$sticker || $sticker->quantity <= 1) {
                $this->session->set_flashdata('error', 'Stiker tidak dapat ditukarkan');
                redirect($_SERVER['HTTP_REFERER']);
                return;
            }
            
            $new_status = !$sticker->is_for_trade;
            if($this->user_model->toggle_trade_status($user_id, $id, $new_status)) {
                $this->session->set_flashdata('success', 
                    'Stiker ' . ($new_status ? 'dapat' : 'tidak dapat') . ' ditukarkan');
            } else {
                $this->session->set_flashdata('error', 'Gagal mengubah status tukar');
            }
            
            redirect($_SERVER['HTTP_REFERER']);
        }
        
        show_404();
    }
    
    public function upload($category_id) {
        // Validasi kategori
        $category = $this->sticker_model->get_category($category_id);
        if (!$category) {
            show_404();
            return;
        }
        
        // Gunakan Image_handler library
        $upload_result = $this->image_handler->upload('image');
        if ($upload_result['status'] === 'error') {
            $this->session->set_flashdata('error', $upload_result['message']);
            redirect('collections/view/'.$category_id);
            return;
        }
        
        // Proses gambar
        $process_result = $this->image_handler->process_sticker_image($upload_result);
        
        // Simpan data stiker
        $sticker_data = [
            'category_id' => $category_id,
            'image_path' => $process_result['file_name'],
            'image_hash' => $process_result['image_hash'],
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $add_result = $this->sticker_model->add_sticker($sticker_data);
        
        if ($add_result['status'] === 'duplicate') {
            $this->image_handler->delete($process_result['file_name']);
            $this->session->set_flashdata('error', 'Stiker ini sudah ada dalam database');
        } else if ($add_result['status'] === 'success') {
            $this->session->set_flashdata('success', 'Stiker berhasil diupload');
        } else {
            $this->image_handler->delete($process_result['file_name']);
            $this->session->set_flashdata('error', 'Gagal menyimpan stiker');
        }
        
        redirect('collections/view/'.$category_id);
    }
    
    public function update_quantity() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $sticker_id = $this->input->post('sticker_id');
        $total_quantity = $this->input->post('total_quantity');
        
        $result = $this->sticker_model->update_sticker_quantity($sticker_id, $total_quantity);
        
        echo json_encode(['success' => $result]);
    }
    
    public function update_owned_quantity() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $user_id = $this->session->userdata('user_id');
        $sticker_id = $this->input->post('sticker_id');
        $owned_quantity = $this->input->post('owned_quantity');
        
        $result = $this->user_model->update_sticker_quantity($user_id, $sticker_id, $owned_quantity);
        
        echo json_encode(['success' => $result]);
    }
    
    private function resize_image($path) {
        $config['image_library'] = 'gd2';
        $config['source_image'] = $path;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 800; // Maksimal lebar
        $config['height'] = 800; // Maksimal tinggi
        
        $this->image_lib->initialize($config);
        $this->image_lib->resize();
    }
} 