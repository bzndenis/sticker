<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->check_login();
        $this->load->model(['sticker_model', 'trade_model', 'user_model']);
    }
    
    public function index() {
        $user_id = $this->session->userdata('user_id');
        
        // Get statistik
        $data['total_stickers'] = $this->user_model->count_user_stickers($user_id);
        $data['total_trades'] = $this->trade_model->count_user_trades($user_id);
        $data['total_collections'] = $this->sticker_model->count_categories();
        
        // Get progress koleksi
        $data['collections'] = $this->sticker_model->get_collections_with_progress($user_id);
        
        // Hitung total progress koleksi
        $total_owned = 0;
        $total_stickers = 0;
        foreach($data['collections'] as $collection) {
            $total_owned += $collection->owned;
            $total_stickers += $collection->total;
        }
        $data['collection_progress'] = $total_stickers > 0 ? 
            round(($total_owned / $total_stickers) * 100, 1) : 0;
        
        // Get aktivitas terbaru
        $data['recent_trades'] = $this->trade_model->get_recent_trades($user_id, 5);
        
        $this->load->view('dashboard/index', $data);
    }
    
    public function get_chart_data() {
        if(!$this->input->is_ajax_request()) {
            show_404();
            return;
        }
        
        $user_id = $this->session->userdata('user_id');
        $period = $this->input->get('period') ?: 'monthly';
        
        // Validasi period
        if(!in_array($period, ['daily', 'weekly', 'monthly'])) {
            $period = 'monthly';
        }
        
        // Get data untuk chart
        $sticker_data = $this->sticker_model->get_user_stickers_chart($user_id, $period);
        $trade_data = $this->trade_model->get_trades_chart($user_id, $period);
        
        // Format data untuk chart
        $formatted_data = [
            'labels' => [],
            'stickers' => [],
            'trades' => []
        ];
        
        // Format sticker data
        foreach($sticker_data as $item) {
            $formatted_data['labels'][] = $this->format_period_label($item->period, $period);
            $formatted_data['stickers'][] = (int)$item->total;
        }
        
        // Format trade data
        foreach($trade_data as $item) {
            if(!in_array($this->format_period_label($item->period, $period), $formatted_data['labels'])) {
                $formatted_data['labels'][] = $this->format_period_label($item->period, $period);
            }
            $formatted_data['trades'][] = (int)$item->total;
        }
        
        // Sort labels chronologically
        sort($formatted_data['labels']);
        
        $this->output->set_content_type('application/json');
        echo json_encode([
            'success' => true,
            'data' => $formatted_data
        ]);
    }
    
    private function format_period_label($period, $type) {
        switch($type) {
            case 'daily':
                return date('d M', strtotime($period));
            case 'weekly':
                $year = substr($period, 0, 4);
                $week = substr($period, -2);
                $dto = new DateTime();
                $dto->setISODate($year, $week);
                return $dto->format('d M');
            case 'monthly':
                return date('M Y', strtotime($period . '-01'));
            default:
                return $period;
        }
    }
} 