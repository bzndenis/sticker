<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->check_admin();
        $this->load->model('sticker_model');
    }
    
    public function index() {
        $data['categories'] = $this->sticker_model->get_categories_with_stats();
        $this->load->view('admin/categories', $data);
    }
    
    public function add() {
        // Validasi form menggunakan form_validation
        $this->form_validation->set_rules('name', 'Nama Kategori', 'required|trim');
        $this->form_validation->set_rules('description', 'Deskripsi', 'trim');
        
        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('admin/categories');
            return;
        }
        
        $name = $this->input->post('name', TRUE);
        
        // Cek duplikasi menggunakan model
        if ($this->sticker_model->get_category_by_name($name)) {
            $this->session->set_flashdata('error', 'Nama kategori sudah digunakan');
            redirect('admin/categories');
            return;
        }
        
        // Siapkan data dengan slug
        $data = [
            'name' => $name,
            'slug' => url_title($name, 'dash', TRUE),
            'description' => $this->input->post('description'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => null
        ];
        
        $this->db->trans_start();
        
        // Simpan kategori
        if ($this->sticker_model->add_category($data)) {
            $category_id = $this->db->insert_id();
            // Inisialisasi 9 slot stiker kosong
            $this->sticker_model->initialize_category_stickers($category_id);
            $this->session->set_flashdata('success', 'Kategori berhasil ditambahkan');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan kategori');
        }
        
        $this->db->trans_complete();
        
        if (!$this->db->trans_status()) {
            $this->session->set_flashdata('error', 'Gagal menambahkan kategori');
        }
        
        redirect('admin/categories');
    }
    
    public function edit($id) {
        $data['category'] = $this->sticker_model->get_category($id);
        if(!$data['category']) {
            show_404();
            return;
        }
        
        if($this->input->post()) {
            $this->form_validation->set_rules('name', 'Nama Kategori', 'required|callback_check_unique_name['.$id.']');
            
            if($this->form_validation->run() === FALSE) {
                $this->session->set_flashdata('error', validation_errors());
            } else {
                $category_data = [
                    'name' => $this->input->post('name'),
                    'description' => $this->input->post('description'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                
                if($this->sticker_model->update_category($id, $category_data)) {
                    $this->session->set_flashdata('success', 'Kategori berhasil diperbarui');
                } else {
                    $this->session->set_flashdata('error', 'Gagal memperbarui kategori');
                }
            }
        }
        
        $this->load->view('admin/categories/edit', $data);
    }
    
    public function delete($id) {
        $category = $this->sticker_model->get_category($id);
        if(!$category) {
            show_404();
            return;
        }
        
        if($this->sticker_model->delete_category($id)) {
            $this->session->set_flashdata('success', 'Kategori berhasil dihapus');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus kategori');
        }
        
        redirect('admin/categories');
    }
    
    public function check_unique_name($name, $id) {
        $existing = $this->db->where('name', $name)
                            ->where('id !=', $id)
                            ->get('sticker_categories')
                            ->row();
                            
        if($existing) {
            $this->form_validation->set_message('check_unique_name', 'Nama kategori sudah digunakan');
            return FALSE;
        }
        return TRUE;
    }
} 