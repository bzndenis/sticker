<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trade_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_trade($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('trades', $data);
    }
    
    public function get_user_trades($user_id, $status = null) {
        $this->db->select('t.*, 
                          rs.image_path as requested_image,
                          os.image_path as offered_image,
                          sc1.name as requested_category,
                          sc2.name as offered_category,
                          u1.username as requester_username,
                          u2.username as owner_username,
                          s1.number as requested_number,
                          s2.number as offered_number')
                 ->from('trades t')
                 ->join('stickers s1', 's1.id = t.requested_sticker_id')
                 ->join('stickers s2', 's2.id = t.offered_sticker_id')
                 ->join('user_stickers rs', 'rs.sticker_id = t.requested_sticker_id AND rs.user_id = t.owner_id')
                 ->join('user_stickers os', 'os.sticker_id = t.offered_sticker_id AND os.user_id = t.requester_id')
                 ->join('sticker_categories sc1', 'sc1.id = s1.category_id')
                 ->join('sticker_categories sc2', 'sc2.id = s2.category_id')
                 ->join('users u1', 'u1.id = t.requester_id')
                 ->join('users u2', 'u2.id = t.owner_id')
                 ->where('(t.requester_id = ' . $user_id . ' OR t.owner_id = ' . $user_id . ')');
        
        if ($status) {
            $this->db->where('t.status', $status);
        }
        
        $this->db->order_by('t.created_at', 'DESC');
        
        // Debug query
        // echo $this->db->get_compiled_select(); die;
        
        return $this->db->get()->result();
    }
    
    public function update_trade_status($trade_id, $status) {
        return $this->db->where('id', $trade_id)
                        ->update('trades', [
                            'status' => $status,
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
    }
    
    public function get_trade($id) {
        $this->db->select('t.*, 
                          rus.image_path as requested_image,
                          ous.image_path as offered_image,
                          u1.username as requester_username,
                          u2.username as owner_username,
                          rsc.name as requested_category,
                          osc.name as offered_category');
        $this->db->from('trades t');
        $this->db->join('stickers rs', 'rs.id = t.requested_sticker_id');
        $this->db->join('stickers os', 'os.id = t.offered_sticker_id');
        $this->db->join('user_stickers rus', 'rus.sticker_id = rs.id AND rus.user_id = t.owner_id', 'left');
        $this->db->join('user_stickers ous', 'ous.sticker_id = os.id AND ous.user_id = t.requester_id', 'left');
        $this->db->join('sticker_categories rsc', 'rsc.id = rs.category_id');
        $this->db->join('sticker_categories osc', 'osc.id = os.category_id');
        $this->db->join('users u1', 'u1.id = t.requester_id');
        $this->db->join('users u2', 'u2.id = t.owner_id');
        $this->db->where('t.id', $id);
        return $this->db->get()->row();
    }

    public function get_recent_trades($user_id, $limit = 5) {
        $this->db->select('t.*, 
                          rus.image_path as requested_image,
                          ous.image_path as offered_image,
                          u1.username as requester_username, 
                          u2.username as owner_username,
                          rsc.name as requested_category,
                          osc.name as offered_category');
        $this->db->from('trades t');
        $this->db->join('stickers rs', 'rs.id = t.requested_sticker_id');
        $this->db->join('stickers os', 'os.id = t.offered_sticker_id');
        $this->db->join('user_stickers rus', 'rus.sticker_id = rs.id AND rus.user_id = t.owner_id', 'left');
        $this->db->join('user_stickers ous', 'ous.sticker_id = os.id AND ous.user_id = t.requester_id', 'left');
        $this->db->join('sticker_categories rsc', 'rsc.id = rs.category_id');
        $this->db->join('sticker_categories osc', 'osc.id = os.category_id');
        $this->db->join('users u1', 'u1.id = t.requester_id');
        $this->db->join('users u2', 'u2.id = t.owner_id');
        $this->db->where("(t.requester_id = $user_id OR t.owner_id = $user_id)");
        $this->db->order_by('t.created_at', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    public function count_user_trades($user_id) {
        $this->db->from('trades');
        $this->db->group_start()
            ->where('requester_id', $user_id)
            ->or_where('owner_id', $user_id)
        ->group_end();
        return $this->db->count_all_results();
    }

    public function count_trades() {
        return $this->db->count_all('trades');
    }

    public function count_pending_trades() {
        return $this->db->where('status', 'pending')->count_all_results('trades');
    }

    public function get_trade_stats() {
        $total_trades = $this->count_trades();
        $pending_trades = $this->count_pending_trades();
        return [
            'total_trades' => $total_trades,
            'pending_trades' => $pending_trades
        ];
    }
    
    public function get_user_trades_chart($user_id, $period = 'monthly') {
        $format = $period == 'daily' ? '%Y-%m-%d' : 
                 ($period == 'weekly' ? '%Y-%u' : '%Y-%m');
                 
        $sql = "SELECT DATE_FORMAT(created_at, ?) as period, 
                COUNT(*) as total,
                MIN(created_at) as min_date
                FROM trades 
                WHERE (requester_id = ? OR owner_id = ?)
                AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
                GROUP BY period
                ORDER BY min_date ASC";
                
        return $this->db->query($sql, [$format, $user_id, $user_id])->result();
    }

    public function get_all_trades($limit = null, $offset = 0) {
        $this->db->select('t.*, 
                          rus.image_path as requested_image,
                          ous.image_path as offered_image,
                          u1.username as requester_username, 
                          u2.username as owner_username,
                          rsc.name as requested_category,
                          osc.name as offered_category');
        $this->db->from('trades t');
        $this->db->join('stickers rs', 'rs.id = t.requested_sticker_id');
        $this->db->join('stickers os', 'os.id = t.offered_sticker_id');
        $this->db->join('user_stickers rus', 'rus.sticker_id = rs.id AND rus.user_id = t.owner_id', 'left');
        $this->db->join('user_stickers ous', 'ous.sticker_id = os.id AND ous.user_id = t.requester_id', 'left');
        $this->db->join('sticker_categories rsc', 'rsc.id = rs.category_id');
        $this->db->join('sticker_categories osc', 'osc.id = os.category_id');
        $this->db->join('users u1', 'u1.id = t.requester_id');
        $this->db->join('users u2', 'u2.id = t.owner_id');
        
        $this->db->order_by('t.created_at', 'DESC');
        
        if($limit) {
            $this->db->limit($limit, $offset);
        }
        
        return $this->db->get()->result();
    }

    public function get_trades_by_status($status, $limit = null) {
        $this->db->select('t.*, 
                          rus.image_path as requested_image,
                          ous.image_path as offered_image,
                          u1.username as requester_username,
                          u2.username as owner_username,
                          rsc.name as requested_category,
                          osc.name as offered_category');
        $this->db->from('trades t');
        $this->db->join('stickers rs', 'rs.id = t.requested_sticker_id');
        $this->db->join('stickers os', 'os.id = t.offered_sticker_id');
        $this->db->join('user_stickers rus', 'rus.sticker_id = rs.id AND rus.user_id = t.owner_id', 'left');
        $this->db->join('user_stickers ous', 'ous.sticker_id = os.id AND ous.user_id = t.requester_id', 'left');
        $this->db->join('sticker_categories rsc', 'rsc.id = rs.category_id');
        $this->db->join('sticker_categories osc', 'osc.id = os.category_id');
        $this->db->join('users u1', 'u1.id = t.requester_id');
        $this->db->join('users u2', 'u2.id = t.owner_id');
        $this->db->where('t.status', $status);
        $this->db->order_by('t.created_at', 'DESC');
        
        if($limit) {
            $this->db->limit($limit);
        }
        
        return $this->db->get()->result();
    }

    public function get_trades_report($start_date = null, $end_date = null, $period = 'monthly') {
        $format = $period == 'daily' ? '%Y-%m-%d' : 
                 ($period == 'weekly' ? '%Y-%u' : '%Y-%m');
                 
        $sql = "SELECT 
                DATE_FORMAT(created_at, ?) as period,
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'accepted' THEN 1 END) as accepted,
                COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected,
                MIN(created_at) as min_date
                FROM trades";
                
        if($start_date && $end_date) {
            $sql .= " WHERE created_at BETWEEN ? AND ?";
        }
        
        $sql .= " GROUP BY period ORDER BY min_date ASC";
        
        $params = [$format];
        if($start_date && $end_date) {
            $params[] = $start_date;
            $params[] = $end_date;
        }
        
        return $this->db->query($sql, $params)->result();
    }

    public function get_trades_chart($user_id, $period = 'monthly') {
        $format = $period == 'daily' ? '%Y-%m-%d' : 
                 ($period == 'weekly' ? '%Y-%u' : '%Y-%m');
                 
        $sql = "SELECT DATE_FORMAT(created_at, ?) as period, 
                COUNT(*) as total,
                MIN(created_at) as min_date
                FROM trades 
                WHERE (requester_id = ? OR owner_id = ?)
                AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
                GROUP BY period
                ORDER BY min_date ASC";
                
        return $this->db->query($sql, [$format, $user_id, $user_id])->result();
    }
} 