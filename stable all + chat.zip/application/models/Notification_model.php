<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notification_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function create_notification($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        return $this->db->insert('notifications', $data);
    }
    
    public function get_user_notifications($user_id, $limit = null, $offset = 0) {
        $this->db->where('user_id', $user_id);
        $this->db->order_by('created_at', 'DESC');
        if($limit) {
            $this->db->limit($limit, $offset);
        }
        return $this->db->get('notifications')->result();
    }
    
    public function count_user_notifications($user_id) {
        return $this->db->where('user_id', $user_id)->count_all_results('notifications');
    }
    
    public function mark_as_read($id, $user_id) {
        return $this->db->where([
            'id' => $id,
            'user_id' => $user_id
        ])->update('notifications', [
            'is_read' => 1
        ]);
    }
    
    public function mark_all_as_read($user_id) {
        return $this->db->where([
            'user_id' => $user_id,
            'is_read' => 0
        ])->update('notifications', [
            'is_read' => 1
        ]);
    }
    
    public function count_unread($user_id) {
        return $this->db->where([
            'user_id' => $user_id,
            'is_read' => 0
        ])->count_all_results('notifications');
    }
    
    public function delete_all($user_id) {
        // Validasi user_id
        if(!$user_id) {
            return false;
        }
        
        // Cek apakah ada notifikasi untuk user ini
        $count = $this->db->where('user_id', $user_id)
                          ->count_all_results('notifications');
        
        if($count == 0) {
            return true; // Return true jika memang tidak ada notifikasi
        }
        
        // Hapus semua notifikasi user
        $result = $this->db->where('user_id', $user_id)
                           ->delete('notifications');
        
        // Log aktivitas jika diperlukan
        if($result) {
            $this->log_notification_deletion($user_id, 'bulk_delete', $count);
        }
        
        return $result;
    }
    
    public function delete_notification($id, $user_id) {
        // Validasi input
        if(!$id || !$user_id) {
            return false;
        }
        
        // Pastikan notifikasi milik user yang benar
        $notification = $this->db->where([
            'id' => $id,
            'user_id' => $user_id
        ])->get('notifications')->row();
        
        if(!$notification) {
            return false;
        }
        
        // Hapus notifikasi
        $result = $this->db->where([
            'id' => $id,
            'user_id' => $user_id
        ])->delete('notifications');
        
        // Log aktivitas jika diperlukan
        if($result) {
            $this->log_notification_deletion($user_id, 'single_delete', 1, $id);
        }
        
        return $result;
    }
    
    private function log_notification_deletion($user_id, $type, $count, $notification_id = null) {
        $log_data = [
            'user_id' => $user_id,
            'action' => 'notification_deletion',
            'type' => $type,
            'count' => $count,
            'notification_id' => $notification_id,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Simpan ke tabel log jika ada
        if($this->db->table_exists('activity_logs')) {
            $this->db->insert('activity_logs', $log_data);
        }
    }
    
    public function get_notification($id, $user_id) {
        return $this->db->where([
            'id' => $id,
            'user_id' => $user_id
        ])->get('notifications')->row();
    }
} 