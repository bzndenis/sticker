<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function login($username, $password) {
        $user = $this->db->get_where('users', ['username' => $username])->row();
        
        if($user && password_verify($password, $user->password)) {
            if($user->is_active) {
                return $user;
            }
        }
        
        return false;
    }
    
    public function register($data) {
        $data['is_active'] = 1;
        $data['is_admin'] = 0;
        return $this->db->insert('users', $data);
    }
    
    public function update_last_login($user_id) {
        // Cek apakah kolom last_login ada
        if ($this->db->field_exists('last_login', 'users')) {
            $this->db->where('id', $user_id);
            return $this->db->update('users', ['last_login' => date('Y-m-d H:i:s')]);
        }
        return true; // Return true jika kolom tidak ada
    }
    
    public function get_user($id) {
        return $this->db->get_where('users', ['id' => $id])->row();
    }
    
    public function get_user_sticker($user_id, $sticker_id) {
        return $this->db->get_where('user_stickers', [
            'user_id' => $user_id,
            'sticker_id' => $sticker_id
        ])->row();
    }
    
    public function update_sticker_quantity($user_id, $sticker_id, $number, $quantity, $image_data = null) {
        // Validasi input
        if(!$user_id || !$sticker_id || !$number) {
            return false;
        }
        
        // Siapkan data dasar
        $data = [
            'user_id' => $user_id,
            'sticker_id' => $sticker_id,
            'number' => $number,
            'quantity' => $quantity,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // Tambahkan data gambar jika ada
        if ($image_data && isset($image_data['file_name']) && isset($image_data['image_hash'])) {
            $data['image_path'] = $image_data['file_name'];
            $data['image_hash'] = $image_data['image_hash'];
        }
        
        // Cek apakah data sudah ada
        $existing = $this->db->get_where('user_stickers', [
            'user_id' => $user_id,
            'sticker_id' => $sticker_id,
            'number' => $number
        ])->row();
        
        if($quantity > 0) {
            if($existing) {
                // Update data yang ada
                $this->db->where([
                    'user_id' => $user_id,
                    'sticker_id' => $sticker_id,
                    'number' => $number
                ]);
                
                // Jika tidak ada gambar baru, jangan update kolom image
                if(!$image_data) {
                    unset($data['image_path']);
                    unset($data['image_hash']);
                }
                
                return $this->db->update('user_stickers', $data);
            } else {
                // Tambah data baru
                $data['created_at'] = date('Y-m-d H:i:s');
                return $this->db->insert('user_stickers', $data);
            }
        } else {
            // Hapus data jika quantity 0
            return $this->db->delete('user_stickers', [
                'user_id' => $user_id,
                'sticker_id' => $sticker_id,
                'number' => $number
            ]);
        }
    }
    
    public function decrease_sticker_quantity($user_id, $sticker_id) {
        $this->db->where([
            'user_id' => $user_id,
            'sticker_id' => $sticker_id
        ]);
        $this->db->set('quantity', 'quantity - 1', FALSE);
        $this->db->set('updated_at', date('Y-m-d H:i:s'));
        return $this->db->update('user_stickers');
    }
    
    public function get_user_tradeable_stickers($user_id) {
        $this->db->select('s.*, us.quantity, us.is_for_trade, us.image_path, us.number');
        $this->db->from('user_stickers us');
        $this->db->join('stickers s', 's.id = us.sticker_id');
        $this->db->join('sticker_categories sc', 'sc.id = s.category_id');
        $this->db->where([
            'us.user_id' => $user_id,
            'us.quantity >' => 1 // Hanya yang punya double
        ]);
        $this->db->order_by('sc.name, us.number');
        return $this->db->get()->result();
    }
    
    public function toggle_trade_status($user_id, $sticker_id, $status) {
        $sticker = $this->get_user_sticker($user_id, $sticker_id);
        
        // Hanya bisa diset untuk trade jika punya lebih dari 1
        if($status && (!$sticker || $sticker->quantity <= 1)) {
            return false;
        }
        
        return $this->db->where([
            'user_id' => $user_id,
            'sticker_id' => $sticker_id
        ])->update('user_stickers', [
            'is_for_trade' => $status ? 1 : 0,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    public function get_collection_progress($user_id) {
        $this->db->select('sc.id, sc.name, 
                          COUNT(DISTINCT s.id) as total_stickers,
                          COUNT(DISTINCT us.sticker_id) as owned_stickers');
        $this->db->from('sticker_categories sc');
        $this->db->join('stickers s', 's.category_id = sc.id', 'left');
        $this->db->join('user_stickers us', 
            'us.sticker_id = s.id AND us.user_id = '.$user_id, 'left');
        $this->db->group_by('sc.id');
        return $this->db->get()->result();
    }
    
    public function count_user_stickers($user_id) {
        return $this->db->where('user_id', $user_id)
                        ->count_all_results('user_stickers');
    }
    
    public function count_users() {
        return $this->db->count_all('users');
    }
    
    public function get_recent_users($limit = 5) {
        $this->db->order_by('created_at', 'DESC');
        $this->db->limit($limit);
        return $this->db->get('users')->result();
    }
    
    public function get_new_users_report($period = 'monthly') {
        $sql = "SELECT DATE_FORMAT(created_at, ?) as period, COUNT(*) as total 
                FROM users 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
                GROUP BY period
                ORDER BY created_at ASC";
                
        $format = $period == 'daily' ? '%Y-%m-%d' : 
                 ($period == 'weekly' ? '%Y-%u' : '%Y-%m');
                 
        return $this->db->query($sql, [$format])->result();
    }
    
    public function get_active_users_report($period = 'monthly') {
        // Cek apakah kolom last_login ada
        if (!$this->db->field_exists('last_login', 'users')) {
            return [];
        }

        $sql = "SELECT DATE_FORMAT(last_login, ?) as period, COUNT(DISTINCT id) as total 
                FROM users 
                WHERE last_login >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
                GROUP BY period
                ORDER BY last_login ASC";
                
        $format = $period == 'daily' ? '%Y-%m-%d' : 
                 ($period == 'weekly' ? '%Y-%u' : '%Y-%m');
                 
        return $this->db->query($sql, [$format])->result();
    }
    
    public function get_collection_progress_report() {
        $this->db->select('u.username, 
                          COUNT(DISTINCT us.sticker_id) as total_stickers,
                          COUNT(DISTINCT s.category_id) as total_categories,
                          (COUNT(DISTINCT us.sticker_id) / 
                           (SELECT COUNT(*) FROM stickers) * 100) as progress');
        $this->db->from('users u');
        $this->db->join('user_stickers us', 'us.user_id = u.id', 'left');
        $this->db->join('stickers s', 's.id = us.sticker_id', 'left');
        $this->db->where('u.is_admin', 0);
        $this->db->group_by('u.id');
        $this->db->order_by('progress', 'DESC');
        return $this->db->get()->result();
    }

    public function get_user_stickers($user_id) {
        $this->db->select('s.id, s.number, us.quantity');
        $this->db->from('user_stickers us');
        $this->db->join('stickers s', 's.id = us.sticker_id');
        $this->db->where('us.user_id', $user_id);
        return $this->db->get()->result();
    }

    public function get_all_users() {
        return $this->db->get('users')->result();
    }
} 