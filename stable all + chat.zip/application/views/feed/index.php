<?php 
$data['title'] = 'Feed Stiker';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Feed Stiker</h2>
            <p class="text-muted mb-0">Temukan stiker yang bisa ditukar</p>
        </div>
        <div class="d-flex gap-2">
            <div class="dropdown">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="bi bi-filter"></i> Filter Kategori
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item <?= !isset($selected_category) ? 'active' : '' ?>" 
                           href="<?= base_url('feed') ?>">Semua Kategori</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <?php foreach($categories as $category): ?>
                        <li>
                            <a class="dropdown-item <?= isset($selected_category) && $selected_category == $category->id ? 'active' : '' ?>" 
                               href="<?= base_url('feed/search?category=' . $category->id) ?>">
                                <?= $category->name ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#searchModal">
                <i class="bi bi-search"></i> Cari Stiker
            </button>
        </div>
    </div>

    <!-- Main Content -->
    <div class="row g-4">
        <?php if(empty($feed_items)): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <div class="mb-4">
                        <i class="bi bi-images text-muted" style="font-size: 4rem;"></i>
                    </div>
                    <h5 class="text-muted mb-2">Belum Ada Stiker</h5>
                    <p class="text-muted">Stiker yang tersedia untuk ditukar akan muncul di sini</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach($feed_items as $item): ?>
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm hover-card">
                        <div class="position-relative">
                            <img src="<?= base_url('uploads/stickers/'.$item->image_path) ?>" 
                                 class="card-img-top" alt="<?= $item->category_name ?>"
                                 style="height: 200px; object-fit: cover;">
                            <div class="position-absolute top-0 end-0 m-2">
                                <span class="badge bg-success rounded-pill">
                                    <i class="bi bi-stack"></i> <?= $item->quantity ?>
                                </span>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-0"><?= $item->category_name ?></h6>
                                <button class="btn btn-link btn-sm text-muted p-0" title="More">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                            </div>
                            <div class="d-flex align-items-center mb-3">
                                <div class="avatar me-2">
                                    <img src="<?= base_url('assets/img/default-avatar.png') ?>" 
                                         class="rounded-circle" width="24" height="24"
                                         alt="<?= $item->username ?>">
                                </div>
                                <small class="text-muted"><?= $item->username ?></small>
                            </div>
                            <div class="card-footer">
                                <?php if($item->can_trade): ?>
                                    <a href="<?= base_url('trades/request/'.$item->sticker_id) ?>" 
                                       class="btn btn-primary w-100">
                                        <i class="bi bi-arrow-left-right"></i> Ajukan Pertukaran
                                    </a>
                                <?php else: ?>
                                    <button class="btn btn-secondary w-100" disabled>
                                        <i class="bi bi-arrow-left-right"></i> Tidak Dapat Ditukar
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Search Modal -->
<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0">
                <h5 class="modal-title">Cari Stiker</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('feed/search') ?>" method="get">
                    <div class="input-group mb-3">
                        <span class="input-group-text bg-transparent border-end-0">
                            <i class="bi bi-search"></i>
                        </span>
                        <input type="text" class="form-control border-start-0" 
                               id="searchInput" 
                               placeholder="Cari berdasarkan kategori...">
                    </div>
                    
                    <div class="categories-container mb-3">
                        <?php foreach($categories as $category): ?>
                            <div class="category-item mb-2">
                                <input type="radio" class="btn-check" 
                                       name="category" 
                                       id="category<?= $category->id ?>" 
                                       value="<?= $category->id ?>"
                                       <?= isset($selected_category) && $selected_category == $category->id ? 'checked' : '' ?>>
                                <label class="btn btn-outline-primary w-100 text-start" 
                                       for="category<?= $category->id ?>">
                                    <?= $category->name ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i> Cari Stiker
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Add custom CSS -->
<style>
.hover-card {
    transition: transform 0.2s, box-shadow 0.2s;
}

.hover-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
}

.avatar {
    width: 24px;
    height: 24px;
    overflow: hidden;
    border-radius: 50%;
}

.avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.dropdown-menu {
    border: none;
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15);
}

.modal-content {
    border: none;
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15);
}

.badge {
    padding: 0.5em 1em;
}

.badge.bg-light {
    border: 1px solid #dee2e6;
}

.categories-container {
    max-height: 300px;
    overflow-y: auto;
}

.category-item .btn {
    text-align: left;
    padding: 0.5rem 1rem;
    font-size: 0.9rem;
}

.category-item .btn-check:checked + .btn-outline-primary {
    background-color: var(--bs-primary);
    color: white;
}

.dropdown-item.active {
    background-color: var(--bs-primary);
    color: white;
}

/* Custom scrollbar for categories */
.categories-container::-webkit-scrollbar {
    width: 6px;
}

.categories-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
}

.categories-container::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 3px;
}

.categories-container::-webkit-scrollbar-thumb:hover {
    background: #555;
}
</style>

<!-- Add search functionality -->
<script>
document.getElementById('searchInput').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const categoryItems = document.querySelectorAll('.category-item');
    
    categoryItems.forEach(item => {
        const label = item.querySelector('label');
        const categoryName = label.textContent.trim().toLowerCase();
        
        if (categoryName.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
});
</script>

<?php $this->load->view('templates/footer'); ?> 