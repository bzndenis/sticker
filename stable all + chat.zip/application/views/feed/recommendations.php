<?php if(empty($recommendations)): ?>
    <div class="text-center py-4">
        <i class="bi bi-emoji-frown text-muted" style="font-size: 2rem;"></i>
        <p class="text-muted mt-2">Belum ada rekomendasi pertukaran</p>
    </div>
<?php else: ?>
    <div class="list-group list-group-flush">
        <?php foreach($recommendations as $rec): ?>
            <div class="list-group-item">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1"><?= $rec->username ?></h6>
                        <p class="mb-1">Memiliki <?= $rec->quantity ?> stiker</p>
                    </div>
                    <a href="<?= base_url('trades/request/'.$rec->sticker_id.'/'.$rec->user_id) ?>" 
                       class="btn btn-sm btn-primary">
                        Ajukan Pertukaran
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?> 