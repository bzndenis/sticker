<?php 
$data['title'] = 'Notifikasi';
$this->load->view('templates/header', $data); 
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Notifikasi</h2>
            <p class="text-muted mb-0">Lihat semua pemberitahuan Anda</p>
        </div>
        <?php if(!empty($notifications)): ?>
            <div class="btn-group">
                <button onclick="markAllRead()" class="btn btn-light">
                    <i class="bi bi-check-all"></i> Tandai Dibaca
                </button>
                <button onclick="deleteAll()" class="btn btn-danger">
                    <i class="bi bi-trash"></i> Hapus Semua
                </button>
            </div>
        <?php endif; ?>
    </div>

    <?php if(empty($notifications)): ?>
        <!-- Empty State -->
        <div class="card">
            <div class="card-body text-center py-5">
                <div class="empty-state">
                    <div class="empty-state-icon mb-4">
                        <i class="bi bi-bell"></i>
                    </div>
                    <h5 class="text-muted mb-2">Tidak Ada Notifikasi</h5>
                    <p class="text-muted mb-0">Anda akan melihat pemberitahuan di sini ketika ada aktivitas baru</p>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- Notification List -->
        <div class="card">
            <div class="list-group list-group-flush notification-list">
                <?php foreach($notifications as $notif): ?>
                    <div class="list-group-item notification-item <?= $notif->is_read ? '' : 'unread' ?>">
                        <div class="d-flex align-items-center">
                            <!-- Notification Icon -->
                            <div class="notification-icon me-3">
                                <?php
                                $icon_class = 'bi-bell';
                                $icon_color = 'primary';
                                
                                switch($notif->type) {
                                    case 'trade_request':
                                        $icon_class = 'bi-arrow-left-right';
                                        $icon_color = 'success';
                                        break;
                                    case 'trade_accepted':
                                        $icon_class = 'bi-check-circle';
                                        $icon_color = 'success';
                                        break;
                                    case 'trade_rejected':
                                        $icon_class = 'bi-x-circle';
                                        $icon_color = 'danger';
                                        break;
                                    case 'new_message':
                                        $icon_class = 'bi-chat-dots';
                                        $icon_color = 'info';
                                        break;
                                }
                                ?>
                                <div class="icon-circle bg-<?= $icon_color ?>-subtle">
                                    <i class="bi <?= $icon_class ?> text-<?= $icon_color ?>"></i>
                                </div>
                            </div>

                            <!-- Notification Content -->
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?= $notif->title ?></h6>
                                        <p class="mb-1 notification-message"><?= $notif->message ?></p>
                                        <small class="text-muted">
                                            <i class="bi bi-clock me-1"></i>
                                            <?= time_elapsed_string($notif->created_at) ?>
                                        </small>
                                    </div>
                                    <?php if(!$notif->is_read): ?>
                                        <button onclick="markRead(<?= $notif->id ?>)" 
                                                class="btn btn-sm btn-light mark-read-btn">
                                            <i class="bi bi-check"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?= $this->pagination->create_links() ?>
        </div>
    <?php endif; ?>
</div>

<!-- Custom CSS -->
<style>
.notification-list {
    max-height: 70vh;
    overflow-y: auto;
}

.notification-item {
    transition: background-color 0.3s;
    border-left: 4px solid transparent;
}

.notification-item:hover {
    background-color: var(--bs-gray-100);
}

.notification-item.unread {
    background-color: var(--bs-gray-100);
    border-left-color: var(--bs-primary);
}

.notification-icon .icon-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.notification-icon i {
    font-size: 1.2rem;
}

.notification-message {
    color: var(--bs-gray-700);
    font-size: 0.95rem;
}

.mark-read-btn {
    opacity: 0;
    transition: opacity 0.3s;
}

.notification-item:hover .mark-read-btn {
    opacity: 1;
}

.empty-state {
    padding: 2rem;
}

.empty-state-icon {
    width: 64px;
    height: 64px;
    background-color: var(--bs-gray-100);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
}

.empty-state-icon i {
    font-size: 2rem;
    color: var(--bs-gray-500);
}

/* Custom Scrollbar */
.notification-list::-webkit-scrollbar {
    width: 6px;
}

.notification-list::-webkit-scrollbar-track {
    background: var(--bs-gray-100);
}

.notification-list::-webkit-scrollbar-thumb {
    background: var(--bs-gray-400);
    border-radius: 3px;
}

.notification-list::-webkit-scrollbar-thumb:hover {
    background: var(--bs-gray-500);
}

.btn-group .btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-group .btn:not(:last-child) {
    border-right: 1px solid rgba(0,0,0,0.1);
}

.btn-danger {
    background-color: var(--bs-danger);
    border-color: var(--bs-danger);
    color: white;
}

.btn-danger:hover {
    background-color: var(--bs-danger-dark);
    border-color: var(--bs-danger-dark);
    color: white;
}

/* Animasi untuk tombol delete */
@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(5px); }
    75% { transform: translateX(-5px); }
}

.btn-danger:hover i {
    animation: shake 0.3s ease-in-out;
}
</style>

<!-- JavaScript -->
<script>
$(document).ready(function() {
    window.markRead = function(id) {
        $.ajax({
            url: '<?= base_url('notifications/mark_read/') ?>' + id,
            type: 'POST',
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    location.reload();
                } else {
                    alert('Gagal menandai notifikasi sebagai telah dibaca');
                }
            },
            error: function() {
                alert('Terjadi kesalahan saat menandai notifikasi');
            }
        });
    }

    window.markAllRead = function() {
        if(confirm('Tandai semua notifikasi sebagai telah dibaca?')) {
            $.ajax({
                url: '<?= base_url('notifications/mark_all_read') ?>',
                type: 'POST',
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        location.reload();
                    } else {
                        alert('Gagal menandai semua notifikasi sebagai telah dibaca');
                    }
                },
                error: function() {
                    alert('Terjadi kesalahan saat menandai notifikasi');
                }
            });
        }
    }

    window.deleteAll = function() {
        if(confirm('Anda yakin ingin menghapus semua notifikasi? Tindakan ini tidak dapat dibatalkan.')) {
            $.ajax({
                url: '<?= base_url('notifications/delete_all') ?>',
                type: 'POST',
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        location.reload();
                    } else {
                        alert(response.message || 'Gagal menghapus notifikasi');
                    }
                },
                error: function() {
                    alert('Terjadi kesalahan saat menghapus notifikasi');
                }
            });
        }
    }
});
</script>

<?php 
// Helper function untuk format waktu
function time_elapsed_string($datetime) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->d == 0) {
        if ($diff->h == 0) {
            if ($diff->i == 0) {
                return "Baru saja";
            }
            return $diff->i . " menit yang lalu";
        }
        return $diff->h . " jam yang lalu";
    }
    if ($diff->d == 1) {
        return "Kemarin";
    }
    if ($diff->d < 7) {
        return $diff->d . " hari yang lalu";
    }
    return date('d M Y H:i', strtotime($datetime));
}
?>

<?php $this->load->view('templates/footer'); ?> 