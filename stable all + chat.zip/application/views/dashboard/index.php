<?php 
$data['title'] = 'Dashboard';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <h2 class="mb-4">Dashboard</h2>

    <!-- Statistik Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <h1 class="display-4 mb-3"><?= $total_stickers ?></h1>
                    <h5 class="card-title text-muted">Total Stiker</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <h1 class="display-4 mb-3"><?= $total_trades ?></h1>
                    <h5 class="card-title text-muted">Total Pertukaran</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-body text-center">
                    <h1 class="display-4 mb-3"><?= $total_collections ?></h1>
                    <h5 class="card-title text-muted">Total Koleksi</h5>
                </div>
            </div>
        </div>
    </div>

    <!-- Progress Koleksi -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">Progress Koleksi</h5>
        </div>
        <div class="card-body">
            <div class="mb-4">
                <h6 class="mb-2">Progress Keseluruhan</h6>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" 
                         style="width: <?= $collection_progress ?>%" 
                         aria-valuenow="<?= $collection_progress ?>" 
                         aria-valuemin="0" 
                         aria-valuemax="100">
                        <?= $collection_progress ?>%
                    </div>
                </div>
            </div>

            <?php foreach($collections as $collection): ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-medium"><?= $collection->name ?></span>
                        <span class="text-muted">
                            <?= $collection->owned ?> dari <?= $collection->total ?> stiker
                        </span>
                    </div>
                    <div class="progress" style="height: 10px;">
                        <div class="progress-bar bg-primary" 
                             role="progressbar" 
                             style="width: <?= $collection->progress ?>%" 
                             aria-valuenow="<?= $collection->progress ?>" 
                             aria-valuemin="0" 
                             aria-valuemax="100">
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="row">
        <!-- Grafik -->
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0">Statistik</h5>
                        <select id="chartPeriod" class="form-select" style="width: auto;">
                            <option value="daily">Harian</option>
                            <option value="weekly">Mingguan</option>
                            <option value="monthly" selected>Bulanan</option>
                        </select>
                    </div>
                    <canvas id="statsChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Notifikasi -->
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Notifikasi</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php if(empty($notifications)): ?>
                        <div class="text-center py-4">
                            <i class="bi bi-bell text-muted" style="font-size: 2rem;"></i>
                            <p class="text-muted mt-2">Tidak ada notifikasi baru</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($notifications as $notif): ?>
                            <?php 
                            // Generate URL berdasarkan tipe notifikasi
                            $action_url = '#';
                            if($notif->type == 'trade_request') {
                                $action_url = base_url('trades/view/'.$notif->reference_id);
                            } else if($notif->type == 'trade_accepted') {
                                $action_url = base_url('trades/view/'.$notif->reference_id);
                            } else if($notif->type == 'trade_rejected') {
                                $action_url = base_url('trades/view/'.$notif->reference_id);
                            }
                            ?>
                            <a href="<?= $action_url ?>" class="list-group-item list-group-item-action">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?= $notif->title ?></h6>
                                        <p class="mb-1 text-muted"><?= $notif->message ?></p>
                                        <small class="text-muted">
                                            <?= date('d M Y H:i', strtotime($notif->created_at)) ?>
                                        </small>
                                    </div>
                                    <?php if(!$notif->is_read): ?>
                                        <span class="badge bg-danger rounded-pill">Baru</span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$data['extra_js'] = "
<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>
<script>
let statsChart;

function updateChart(period) {
    fetch('" . base_url('dashboard/get_chart_data') . "?period=' + period)
        .then(response => response.json())
        .then(data => {
            if(statsChart) statsChart.destroy();
            
            statsChart = new Chart(document.getElementById('statsChart'), {
                type: 'line',
                data: {
                    labels: data.trades.map(item => item.period),
                    datasets: [{
                        label: 'Pertukaran',
                        data: data.trades.map(item => item.total),
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1
                    }, {
                        label: 'Stiker Baru',
                        data: data.stickers.map(item => item.total),
                        borderColor: 'rgb(54, 162, 235)',
                        tension: 0.1
                    }]
                }
            });
        });
}

document.getElementById('chartPeriod').addEventListener('change', function() {
    updateChart(this.value);
});

updateChart('monthly');
</script>
";
?>

<?php $this->load->view('templates/footer', $data); ?> 