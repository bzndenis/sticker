<?php 
$data['title'] = 'Pertukaran Stiker';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <h2 class="mb-4">Pertukaran Stiker</h2>

    <!-- Pertukaran yang Pending -->
    <?php if(!empty($pending_trades)): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Pertukaran yang Menunggu</h5>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <?php foreach($pending_trades as $trade): ?>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div>
                                            <h6 class="card-subtitle text-muted">Pemohon</h6>
                                            <p class="mb-0"><?= $trade->requester_username ?></p>
                                        </div>
                                        <div class="text-end">
                                            <h6 class="card-subtitle text-muted">Pemilik</h6>
                                            <p class="mb-0"><?= $trade->owner_username ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-6 text-center">
                                            <small class="text-muted d-block mb-2">Stiker yang Diminta</small>
                                            <img src="<?= base_url('uploads/stickers/'.$trade->requested_image) ?>" 
                                                 class="img-fluid rounded mb-2" style="max-height: 100px;">
                                            <p class="mb-0">
                                                <?= $trade->requested_category ?> #<?= $trade->requested_number ?>
                                            </p>
                                        </div>
                                        <div class="col-6 text-center">
                                            <small class="text-muted d-block mb-2">Stiker yang Ditawarkan</small>
                                            <img src="<?= base_url('uploads/stickers/'.$trade->offered_image) ?>" 
                                                 class="img-fluid rounded mb-2" style="max-height: 100px;">
                                            <p class="mb-0">
                                                <?= $trade->offered_category ?> #<?= $trade->offered_number ?>
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center mt-3">
                                        <a href="<?= base_url('trades/view/'.$trade->id) ?>" 
                                           class="btn btn-primary btn-sm">
                                            <i class="bi bi-chat-dots"></i> Lihat Detail
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $this->load->view('templates/footer'); ?> 