<?php 
$data['title'] = 'Detail Pertukaran';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Detail Pertukaran</h2>
        <a href="<?= base_url('trades') ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
    </div>

    <div class="row">
        <!-- Detail Pertukaran -->
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Informasi Pertukaran</h5>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <small class="text-muted d-block mb-1">Status</small>
                        <?php
                        $status_class = [
                            'pending' => 'warning',
                            'accepted' => 'success',
                            'rejected' => 'danger',
                            'cancelled' => 'secondary'
                        ];
                        ?>
                        <span class="badge bg-<?= $status_class[$trade->status] ?>">
                            <?= ucfirst($trade->status) ?>
                        </span>
                    </div>

                    <div class="mb-4">
                        <small class="text-muted d-block mb-1">Pemohon</small>
                        <strong><?= $trade->requester_username ?></strong>
                    </div>

                    <div class="mb-4">
                        <small class="text-muted d-block mb-1">Pemilik</small>
                        <strong><?= $trade->owner_username ?></strong>
                    </div>

                    <div class="mb-4">
                        <small class="text-muted d-block mb-1">Tanggal Request</small>
                        <strong><?= date('d M Y H:i', strtotime($trade->created_at)) ?></strong>
                    </div>

                    <?php if($trade->status === 'pending' && $trade->owner_id === $this->session->userdata('user_id')): ?>
                        <div class="d-grid gap-2">
                            <button onclick="acceptTrade(<?= $trade->id ?>)" class="btn btn-success">
                                <i class="bi bi-check-lg"></i> Terima
                            </button>
                            <button onclick="rejectTrade(<?= $trade->id ?>)" class="btn btn-danger">
                                <i class="bi bi-x-lg"></i> Tolak
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Detail Stiker -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Detail Stiker</h5>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <small class="text-muted d-block mb-2">Stiker yang Diminta</small>
                        <img src="<?= base_url('uploads/stickers/'.$trade->requested_image) ?>" 
                             class="img-fluid rounded mb-2" alt="Stiker yang Diminta">
                        <p class="mb-0">Stiker #<?= $trade->requested_number ?></p>
                    </div>

                    <div class="text-center my-3">
                        <i class="bi bi-arrow-down"></i>
                    </div>

                    <div>
                        <small class="text-muted d-block mb-2">Stiker yang Ditawarkan</small>
                        <img src="<?= base_url('uploads/stickers/'.$trade->offered_image) ?>" 
                             class="img-fluid rounded mb-2" alt="Stiker yang Ditawarkan">
                        <p class="mb-0">Stiker #<?= $trade->offered_number ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chat -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Chat Pertukaran</h5>
                </div>
                <div class="card-body">
                    <!-- Chat Area -->
                    <div class="chat-messages" id="chatMessages" style="height: 400px; overflow-y: auto;">
                        <?php foreach($messages as $msg): ?>
                            <?php 
                            $is_mine = ($msg->user_id == $this->session->userdata('user_id')); 
                            ?>
                            <div class="message mb-3 <?= $is_mine ? 'text-end' : '' ?>">
                                <div class="d-inline-block" style="max-width: 70%;" data-message-id="<?= $msg->id ?>">
                                    <?php if(!$is_mine): ?>
                                        <small class="text-muted d-block mb-1"><?= $msg->username ?></small>
                                    <?php endif; ?>
                                    <div class="px-3 py-2 rounded <?= $is_mine ? 'bg-primary text-white' : 'bg-light' ?>" 
                                         style="word-wrap: break-word;">
                                        <?= htmlspecialchars($msg->message) ?>
                                    </div>
                                    <small class="text-muted d-block mt-1">
                                        <?= date('H:i', strtotime($msg->created_at)) ?>
                                        <?php if($is_mine): ?>
                                            <span class="ms-1 message-status" title="Status Pesan">
                                                <?php if($msg->read_at): ?>
                                                    <i class="bi bi-check2-all text-primary"></i>
                                                <?php elseif($msg->is_delivered): ?>
                                                    <i class="bi bi-check2-all"></i>
                                                <?php else: ?>
                                                    <i class="bi bi-check2"></i>
                                                <?php endif; ?>
                                            </span>
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if($trade->status === 'pending'): ?>
                        <form id="chatForm" class="mt-3">
                            <div class="d-flex gap-2">
                                <input type="hidden" name="trade_id" value="<?= $trade->id ?>">
                                <textarea name="message" class="form-control" rows="1" 
                                        placeholder="Ketik pesan..." required></textarea>
                                <button type="submit" class="btn btn-primary px-3">
                                    <i class="bi bi-send"></i>
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let lastMessageId = <?= empty($messages) ? 0 : end($messages)->id ?>;
const chatMessages = document.getElementById('chatMessages');
const chatForm = document.getElementById('chatForm');

// Auto scroll ke bawah
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Format waktu
function formatTime(date) {
    return new Date(date).toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Tambah pesan baru
function appendMessage(message, isMine = false) {
    const html = `
        <div class="message mb-3 ${isMine ? 'text-end' : ''}">
            <div class="d-inline-block" style="max-width: 70%;" data-message-id="${message.id}">
                ${!isMine ? `<small class="text-muted d-block mb-1">${message.username}</small>` : ''}
                <div class="px-3 py-2 rounded ${isMine ? 'bg-primary text-white' : 'bg-light'}" 
                     style="word-wrap: break-word;">
                    ${message.message}
                </div>
                <small class="text-muted d-block mt-1">
                    ${message.created_at}
                    ${isMine ? `
                        <span class="ms-1 message-status" title="Status Pesan">
                            <i class="bi <?= $msg->is_read ? 'bi-check2-all' : 'bi-check2' ?>"></i>
                        </span>
                    ` : ''}
                </small>
            </div>
        </div>
    `;
    chatMessages.insertAdjacentHTML('beforeend', html);
    scrollToBottom();
}

// Kirim pesan
chatForm?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const textarea = form.querySelector('textarea');
    const message = textarea.value.trim();
    
    if(!message) return;
    
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('<?= site_url('trades/send_message') ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                trade_id: <?= $trade->id ?>,
                message: message
            })
        });
        
        const data = await response.json();
        
        if(data.success) {
            textarea.value = '';
            appendMessage(data.message, true);
        } else {
            alert(data.message || 'Gagal mengirim pesan');
        }
    } catch(error) {
        alert('Terjadi kesalahan saat mengirim pesan');
        console.error('Error:', error);
    } finally {
        submitBtn.disabled = false;
        textarea.focus();
    }
});

// Auto resize textarea
const textarea = document.querySelector('textarea[name="message"]');
textarea?.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

// Tambahkan fungsi untuk menandai pesan dibaca saat halaman dibuka
async function markMessagesAsRead() {
    try {
        const response = await fetch('<?= site_url('trades/mark_messages_read') ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                trade_id: <?= $trade->id ?>
            })
        });
        const data = await response.json();
        if(!data.success) {
            console.error('Failed to mark messages as read');
        }
    } catch(error) {
        console.error('Error marking messages as read:', error);
    }
}

// Panggil fungsi saat halaman dibuka
document.addEventListener('DOMContentLoaded', markMessagesAsRead);

// Update fungsi updateMessageStatus
function updateMessageStatus(messageId, status) {
    const messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
    if (messageElement) {
        const statusIcon = messageElement.querySelector('.message-status .bi');
        if (statusIcon) {
            if (status.read_at) {
                statusIcon.className = 'bi bi-check2-all text-primary';
                statusIcon.title = 'Dibaca';
            } else if (status.is_delivered) {
                statusIcon.className = 'bi bi-check2-all';
                statusIcon.title = 'Tersampaikan';
            } else {
                statusIcon.className = 'bi bi-check2';
                statusIcon.title = 'Terkirim';
            }
        }
    }
}

// Polling pesan dan status
async function pollMessages() {
    try {
        const [messagesResponse, statusResponse] = await Promise.all([
            fetch(`<?= site_url('trades/get_new_messages') ?>?trade_id=<?= $trade->id ?>&last_id=${lastMessageId}`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            }),
            fetch(`<?= site_url('trades/get_message_status') ?>?trade_id=<?= $trade->id ?>`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
        ]);

        const messagesData = await messagesResponse.json();
        const statusData = await statusResponse.json();

        // Handle pesan baru
        if(messagesData.success && messagesData.messages.length > 0) {
            messagesData.messages.forEach(message => {
                appendMessage(message, false);
                lastMessageId = Math.max(lastMessageId, message.id);
            });
        }

        // Update status pesan
        if(statusData.success && statusData.messages) {
            statusData.messages.forEach(msg => {
                updateMessageStatus(msg.id, msg);
            });
        }
    } catch(error) {
        console.error('Error polling:', error);
    }
}

// Mulai polling setiap 3 detik
const pollInterval = setInterval(pollMessages, 3000);

// Hentikan polling saat halaman ditutup
window.addEventListener('beforeunload', function() {
    clearInterval(pollInterval);
});

// Scroll ke bawah saat pertama kali load
scrollToBottom();

function acceptTrade(id) {
    if(confirm('Apakah Anda yakin ingin menerima pertukaran ini?')) {
        window.location.href = '<?= base_url('trades/accept/') ?>' + id;
    }
}

function rejectTrade(id) {
    if(confirm('Apakah Anda yakin ingin menolak pertukaran ini?')) {
        window.location.href = '<?= base_url('trades/reject/') ?>' + id;
    }
}
</script>

<?php $this->load->view('templates/footer'); ?> 