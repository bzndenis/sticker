<?php 
$data['title'] = 'Ajukan Pertukaran';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Ajukan Pertukaran</h2>
        <a href="<?= base_url('feed') ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Kembali
        </a>
    </div>

    <?= form_open('trades/submit_request') ?>
        <input type="hidden" name="requested_sticker_id" value="<?= $requested_sticker->id ?>">
        <input type="hidden" name="owner_id" value="<?= $requested_sticker->owner_id ?>">

        <div class="row mb-4">
            <!-- Stiker yang Diminta -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title text-center mb-3">Stiker yang Diminta</h5>
                        <img src="<?= $requested_sticker->image_path ? 
                            base_url('uploads/stickers/'.$requested_sticker->image_path) : 
                            base_url('assets/images/no-image.png') ?>" 
                             class="img-fluid rounded mb-3 mx-auto d-block" style="max-height: 200px; object-fit: contain;">
                        <p class="text-center mb-0">
                            Stiker #<?= $requested_sticker->number ?>
                        </p>
                        <p class="text-center text-muted">
                            Pemilik: <?= $requested_sticker->owner_username ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Stiker yang Ditawarkan -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title text-center mb-3">Pilih Stiker untuk Ditukar</h5>
                        
                        <?php if(empty($tradeable_stickers)): ?>
                            <div class="text-center text-muted">
                                <i class="bi bi-emoji-frown" style="font-size: 2rem;"></i>
                                <p class="mt-2">Anda tidak memiliki stiker yang dapat ditukarkan</p>
                            </div>
                        <?php else: ?>
                            <select name="offered_sticker_id" class="form-select" required>
                                <option value="">Pilih stiker...</option>
                                <?php foreach($tradeable_stickers as $sticker): ?>
                                    <option value="<?= $sticker->id ?>">
                                        Stiker #<?= $sticker->number ?> - 
                                        Tersedia: <?= $sticker->quantity - 1 ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary" 
                    <?= empty($tradeable_stickers) ? 'disabled' : '' ?>>
                <i class="bi bi-arrow-left-right"></i> Ajukan Pertukaran
            </button>
        </div>
    <?= form_close() ?>
</div>

<?php $this->load->view('templates/footer'); ?> 