<?php 
$data['title'] = 'Dashboard Admin';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/admin_navbar'); ?>

<div class="container my-4">
    <h2 class="mb-4">Dashboard Admin</h2>

    <!-- Statistik Utama -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-0">Total Pengguna</h6>
                            <h2 class="mb-0"><?= $total_users ?></h2>
                        </div>
                        <i class="bi bi-people" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-0">Total Koleksi</h6>
                            <h2 class="mb-0"><?= $total_collections ?></h2>
                        </div>
                        <i class="bi bi-collection" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-0">Total Stiker</h6>
                            <h2 class="mb-0"><?= $total_stickers ?></h2>
                        </div>
                        <i class="bi bi-images" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-0">Total Pertukaran</h6>
                            <h2 class="mb-0"><?= $total_trades ?></h2>
                        </div>
                        <i class="bi bi-arrow-left-right" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Grafik -->
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0">Statistik</h5>
                        <select id="chartPeriod" class="form-select" style="width: auto;">
                            <option value="daily">Harian</option>
                            <option value="weekly">Mingguan</option>
                            <option value="monthly" selected>Bulanan</option>
                        </select>
                    </div>
                    <canvas id="statsChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Pertukaran Pending -->
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Pertukaran Pending</h5>
                </div>
                <div class="card-body">
                    <?php if(empty($pending_trades)): ?>
                        <div class="text-center py-3">
                            <i class="bi bi-check2-circle text-muted" style="font-size: 2rem;"></i>
                            <p class="text-muted mt-2">Tidak ada pertukaran pending</p>
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach($pending_trades as $trade): ?>
                                <a href="<?= base_url('admin/trades/view/'.$trade->id) ?>" 
                                   class="list-group-item list-group-item-action">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1"><?= $trade->requester_username ?></h6>
                                            <small class="text-muted">
                                                <?= $trade->requested_sticker_name ?> ⟷ <?= $trade->offered_sticker_name ?>
                                            </small>
                                        </div>
                                        <small class="text-muted">
                                            <?= date('d M Y', strtotime($trade->created_at)) ?>
                                        </small>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$data['extra_js'] = '
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
let statsChart;

function updateChart(period) {
    fetch(`'.base_url('admin/dashboard/get_chart_data').'?period=${period}`)
        .then(response => response.json())
        .then(data => {
            if(statsChart) statsChart.destroy();
            
            statsChart = new Chart(document.getElementById("statsChart"), {
                type: "line",
                data: {
                    labels: data.trades.map(item => item.period),
                    datasets: [{
                        label: "Pengguna Baru",
                        data: data.new_users.map(item => item.total),
                        borderColor: "rgb(75, 192, 192)",
                        tension: 0.1
                    }, {
                        label: "Pengguna Aktif",
                        data: data.active_users.map(item => item.total),
                        borderColor: "rgb(54, 162, 235)",
                        tension: 0.1
                    }, {
                        label: "Pertukaran",
                        data: data.trades.map(item => item.total),
                        borderColor: "rgb(255, 99, 132)",
                        tension: 0.1
                    }]
                }
            });
        });
}

document.getElementById("chartPeriod").addEventListener("change", function() {
    updateChart(this.value);
});

updateChart("monthly");
</script>
';
?>

<?php $this->load->view('templates/footer', $data); ?> 