<?php 
$data['title'] = 'Edit Kategori';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/admin_navbar'); ?>

<div class="container my-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title mb-0">Edit Kategori</h4>
                        <a href="<?= base_url('admin/categories') ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                    </div>

                    <?php if(validation_errors()): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <?= validation_errors() ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?= form_open('admin/categories/edit/'.$category->id) ?>
                        <div class="mb-3">
                            <label class="form-label">Nama Kategori</label>
                            <input type="text" name="name" class="form-control" 
                                   value="<?= set_value('name', $category->name) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="description" class="form-control" rows="3"><?= set_value('description', $category->description) ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Statistik</label>
                            <div class="row text-center">
                                <div class="col-6">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h3 class="mb-1"><?= $category->total_collections ?></h3>
                                            <small class="text-muted">Total Koleksi</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h3 class="mb-1"><?= $category->total_stickers ?></h3>
                                            <small class="text-muted">Total Stiker</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save"></i> Simpan Perubahan
                            </button>
                            <?php if($category->total_collections == 0): ?>
                                <button type="button" onclick="deleteCategory(<?= $category->id ?>, '<?= $category->name ?>')" 
                                        class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Hapus Kategori
                                </button>
                            <?php endif; ?>
                        </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function deleteCategory(id, name) {
    if(confirm(`Apakah Anda yakin ingin menghapus kategori "${name}"?`)) {
        window.location.href = '<?= base_url('admin/categories/delete/') ?>' + id;
    }
}
</script>

<?php $this->load->view('templates/footer'); ?> 