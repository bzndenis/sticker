<?php 
$data['title'] = 'Kategori';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/admin_navbar'); ?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Kategori Stiker</h2>
        <a href="<?= base_url('admin/categories/add') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Tambah Kategori
        </a>
    </div>

    <?php if($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= $this->session->flashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $this->session->flashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <th>Total Koleksi</th>
                            <th>Total Stiker</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($categories)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">
                                    <i class="bi bi-tags text-muted" style="font-size: 2rem;"></i>
                                    <p class="text-muted mt-2">Belum ada kategori</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($categories as $category): ?>
                                <tr>
                                    <td><?= $category->name ?></td>
                                    <td><?= $category->description ?: '-' ?></td>
                                    <td><?= $category->total_collections ?></td>
                                    <td><?= $category->total_stickers ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= base_url('admin/categories/edit/'.$category->id) ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <?php if($category->total_collections == 0): ?>
                                                <button onclick="deleteCategory(<?= $category->id ?>, '<?= $category->name ?>')" 
                                                        class="btn btn-sm btn-danger">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function deleteCategory(id, name) {
    if(confirm(`Apakah Anda yakin ingin menghapus kategori "${name}"?`)) {
        window.location.href = '<?= base_url('admin/categories/delete/') ?>' + id;
    }
}
</script>

<?php $this->load->view('templates/footer'); ?> 