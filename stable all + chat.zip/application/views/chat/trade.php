<?php 
$data['title'] = 'Chat Pertukaran';
$this->load->view('templates/header', $data); 
?>

<?php $this->load->view('templates/navbar'); ?>

<div class="container my-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <!-- Header Chat -->
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-1">Chat Pertukaran</h5>
                            <div class="d-flex align-items-center gap-2">
                                <span><?= $trade->requested_sticker_name ?></span>
                                <i class="bi bi-arrow-left-right"></i>
                                <span><?= $trade->offered_sticker_name ?></span>
                            </div>
                            <small class="text-muted">
                                dengan <?= $trade->requester_id == $this->session->userdata('user_id') ? 
                                          $trade->owner_username : 
                                          $trade->requester_username ?>
                            </small>
                        </div>
                        <div>
                            <a href="<?= base_url('trades/view/'.$trade->id) ?>" 
                               class="btn btn-outline-primary">
                                <i class="bi bi-arrow-left-right"></i> Detail Pertukaran
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Area Chat -->
                <div class="card-body" style="height: 400px; overflow-y: auto;" id="chatArea">
                    <?php if(empty($messages)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-chat-dots text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-3">Belum ada pesan</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($messages as $message): ?>
                            <?php $is_sender = $message->sender_id == $this->session->userdata('user_id'); ?>
                            <div class="d-flex mb-3 <?= $is_sender ? 'justify-content-end' : 'justify-content-start' ?>">
                                <div class="<?= $is_sender ? 'bg-primary text-white' : 'bg-light' ?> 
                                            rounded p-2" style="max-width: 70%;">
                                    <div class="small fw-bold mb-1">
                                        <?= $message->sender_username ?>
                                    </div>
                                    <?= nl2br(htmlspecialchars($message->message)) ?>
                                    <div class="small <?= $is_sender ? 'text-white-50' : 'text-muted' ?> mt-1">
                                        <?= date('d M Y H:i', strtotime($message->created_at)) ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Form Input -->
                <div class="card-footer bg-white">
                    <form id="chatForm" class="d-flex gap-2">
                        <input type="hidden" name="trade_id" value="<?= $trade->id ?>">
                        <textarea name="message" class="form-control" rows="1" 
                                placeholder="Tulis pesan..." required></textarea>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-send"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const chatArea = document.getElementById('chatArea');
const chatForm = document.getElementById('chatForm');
let lastMessageId = <?= empty($messages) ? 0 : end($messages)->id ?>;

// Scroll ke bawah
chatArea.scrollTop = chatArea.scrollHeight;

// Kirim pesan
chatForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('<?= base_url('chat/send') ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.status === 'success') {
            chatForm.reset();
            getNewMessages();
        }
    });
});

// Polling pesan baru
function getNewMessages() {
    fetch(`<?= base_url('chat/get_new_messages') ?>?trade_id=<?= $trade->id ?>&last_id=${lastMessageId}`)
        .then(response => response.json())
        .then(data => {
            if(data.status === 'success' && data.messages.length > 0) {
                data.messages.forEach(message => {
                    const isSender = message.sender_id == <?= $this->session->userdata('user_id') ?>;
                    const html = `
                        <div class="d-flex mb-3 ${isSender ? 'justify-content-end' : 'justify-content-start'}">
                            <div class="${isSender ? 'bg-primary text-white' : 'bg-light'} 
                                        rounded p-2" style="max-width: 70%;">
                                <div class="small fw-bold mb-1">
                                    ${message.sender_username}
                                </div>
                                ${message.message}
                                <div class="small ${isSender ? 'text-white-50' : 'text-muted'} mt-1">
                                    ${new Date(message.created_at).toLocaleString()}
                                </div>
                            </div>
                        </div>
                    `;
                    chatArea.insertAdjacentHTML('beforeend', html);
                    lastMessageId = message.id;
                });
                chatArea.scrollTop = chatArea.scrollHeight;
            }
        });
}

// Polling setiap 3 detik
setInterval(getNewMessages, 3000);
</script>

<?php $this->load->view('templates/footer'); ?> 