<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Sticker Exchange</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php $this->load->view('templates/header', ['title' => 'Profil']); ?>

    <?php $this->load->view('templates/navbar'); ?>

    <div class="container my-4">
        <div class="row">
            <div class="col-md-4">
                <!-- Profil Card -->
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <i class="bi bi-person-circle" style="font-size: 5rem;"></i>
                        </div>
                        <h4 class="mb-1"><?= $user->username ?></h4>
                        <p class="text-muted mb-3"><?= $user->email ?></p>
                        <div class="d-grid">
                            <a href="<?= base_url('profile/edit') ?>" class="btn btn-primary">
                                <i class="bi bi-pencil"></i> Edit Profil
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Statistik Card -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Statistik</h5>
                        <div class="row text-center">
                            <div class="col-6 mb-3">
                                <h2 class="mb-1"><?= $total_stickers ?></h2>
                                <small class="text-muted">Total Stiker</small>
                            </div>
                            <div class="col-6 mb-3">
                                <h2 class="mb-1"><?= $total_trades ?></h2>
                                <small class="text-muted">Total Pertukaran</small>
                            </div>
                            <div class="col-12">
                                <h2 class="mb-1"><?= count($collections) ?></h2>
                                <small class="text-muted">Total Koleksi</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <!-- Progress Koleksi Section -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Progress Koleksi</h5>
                    </div>
                    <div class="card-body">
                        <?php if(empty($collections)): ?>
                            <p class="text-muted text-center mb-0">Belum ada koleksi</p>
                        <?php else: ?>
                            <?php foreach($collections as $collection): ?>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="fw-medium"><?= $collection->name ?></span>
                                        <span class="text-muted">
                                            <?= $collection->owned ?> dari <?= $collection->total ?> stiker
                                        </span>
                                    </div>
                                    <div class="progress" style="height: 10px;">
                                        <div class="progress-bar bg-primary" 
                                             role="progressbar" 
                                             style="width: <?= $collection->progress ?>%" 
                                             aria-valuenow="<?= $collection->progress ?>" 
                                             aria-valuemin="0" 
                                             aria-valuemax="100">
                                            <span class="progress-text"><?= $collection->progress ?>%</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $this->load->view('templates/footer'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 