<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> - Sticker Exchange</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom CSS -->
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .sticker-img {
            max-height: 200px;
            object-fit: contain;
        }
        
        .feed-img {
            height: 200px;
            object-fit: cover;
        }
        
        .chat-messages {
            max-height: 400px;
            overflow-y: auto;
        }
        
        #notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            transform: translate(50%, -50%);
        }

        /* Dropdown styles */
        .dropdown-menu {
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            border: none;
            border-radius: 0.5rem;
        }

        .dropdown-item {
            padding: 0.5rem 1rem;
            transition: all 0.2s ease;
        }

        .dropdown-item:hover {
            background-color: var(--bs-light);
        }

        .dropdown-item:active {
            background-color: var(--bs-primary);
            color: white;
        }

        .dropdown-toggle::after {
            vertical-align: middle;
        }

        /* Navbar dropdown styles */
        .nav-item.dropdown .btn-link {
            color: rgba(255,255,255,.55);
            text-decoration: none;
            padding: 0.5rem 1rem;
            background: none;
            border: none;
        }

        .nav-item.dropdown .btn-link:hover,
        .nav-item.dropdown .btn-link:focus {
            color: rgba(255,255,255,.75);
        }

        .nav-item.dropdown .btn-link.show {
            color: #fff;
        }

        .dropdown-menu {
            margin-top: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,.15);
            border: none;
            border-radius: 0.5rem;
        }

        .dropdown-item {
            padding: 0.5rem 1rem;
            display: flex;
            align-items: center;
        }

        .dropdown-item i {
            width: 1.2rem;
            font-size: 1.1rem;
        }

        .dropdown-item:hover {
            background-color: var(--bs-light);
        }

        .dropdown-item.text-danger:hover {
            background-color: rgba(var(--bs-danger-rgb), 0.1);
        }

        /* Notification badge positioning */
        .nav-item {
            position: relative;
        }

        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            transform: translate(25%, -25%);
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
            line-height: 1;
            border-radius: 0.75rem;
            background-color: var(--bs-danger);
            color: white;
            min-width: 1rem;
            text-align: center;
        }

        /* Hover effect untuk notification icon */
        .nav-link:hover .bi-bell {
            animation: bell-shake 0.5s ease;
        }

        @keyframes bell-shake {
            0% { transform: rotate(0); }
            25% { transform: rotate(10deg); }
            50% { transform: rotate(0); }
            75% { transform: rotate(-10deg); }
            100% { transform: rotate(0); }
        }
    </style>
</head>
<body>

<!-- Optional: Inisialisasi dropdown secara global -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi semua dropdown
    var dropdownElementList = [].slice.call(document.querySelectorAll('[data-bs-toggle="dropdown"]'))
    var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
        return new bootstrap.Dropdown(dropdownToggleEl, {
            offset: [0, 10],
            boundary: 'viewport'
        });
    });

    // Event listener untuk hover pada desktop
    if (window.matchMedia('(min-width: 992px)').matches) {
        document.querySelectorAll('.dropdown').forEach(function(dropdown) {
            dropdown.addEventListener('mouseenter', function() {
                var dropdownToggle = this.querySelector('.dropdown-toggle');
                var dropdownInstance = bootstrap.Dropdown.getInstance(dropdownToggle);
                if (dropdownInstance) {
                    dropdownInstance.show();
                }
            });

            dropdown.addEventListener('mouseleave', function() {
                var dropdownToggle = this.querySelector('.dropdown-toggle');
                var dropdownInstance = bootstrap.Dropdown.getInstance(dropdownToggle);
                if (dropdownInstance) {
                    dropdownInstance.hide();
                }
            });
        });
    }
});
</script>
</rewritten_file> 